import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Verify exact injection points against the user's installed binaries. */
public class VerifyHooks {
    static ClassNode read(JarFile jar, String name) throws Exception {
        ClassNode node = new ClassNode();
        new ClassReader(jar.getInputStream(jar.getJarEntry(name + ".class"))).accept(node, 0);
        return node;
    }
    static MethodNode method(ClassNode node, String name, String desc) {
        return node.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(desc))
            .findFirst().orElseThrow(() -> new AssertionError(node.name + "." + name + desc));
    }
    static void modelHook(MethodNode method) {
        int count = 0;
        for (AbstractInsnNode insn : method.instructions)
            if (insn instanceof MethodInsnNode call && call.name.equals("getModel")
                && call.owner.equals("net/minecraft/client/renderer/entity/LivingEntityRenderer")
                && call.desc.equals("()Lnet/minecraft/client/model/EntityModel;")) count++;
        if (count != 1) throw new AssertionError("Expected one model hook, got " + count);
    }
    public static void main(String[] args) throws Exception {
        try (JarFile sable = new JarFile(args[0]); JarFile emf = new JarFile(args[1])) {
            String base = "dev/leo/sableplayerragdoll/mob/client/";
            modelHook(method(read(sable, base + "MobRagdollClientExtractor"), "extractAndSend",
                "(Lnet/minecraft/world/entity/LivingEntity;)V"));
            modelHook(method(read(sable, base + "MobRagdollPartBlockEntityRenderer"), "renderReplay",
                "(Ldev/leo/sableplayerragdoll/mob/block/entity/MobRagdollPartBlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)Z"));
            String parts = "traben/entity_model_features/models/parts/";
            ClassNode root = read(emf, parts + "EMFModelPartRoot");
            for (String name : new String[]{"animate", "animateNoPause", "oneTimeRunnable"})
                method(root, name, "()V");
            ClassNode part = read(emf, parts + "EMFModelPart");
            String renderDesc = "(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;III)V";
            method(part, "render", renderDesc);
            method(part, "renderLikeVanilla", renderDesc);
            ClassNode state = read(emf, parts + "EMFModelPartWithState");
            method(state, "setVariantStateTo", "(I)V");
            if (state.fields.stream().noneMatch(f -> f.name.equals("currentModelVariant") && f.desc.equals("I")))
                throw new AssertionError("Missing variant field");
            for (String className : new String[]{"MobRagdollPartBlockEntityRenderer", "MobRagdollQuadRenderer"}) {
                ClassNode renderer = read(sable, base + className);
                int count = 0;
                for (MethodNode m : renderer.methods)
                    if (m.name.equals(className.contains("Quad") ? "render" : "renderReplay"))
                        for (AbstractInsnNode insn : m.instructions)
                            if (insn instanceof MethodInsnNode call && call.name.equals("texture")
                                && call.owner.equals("dev/leo/sableplayerragdoll/mob/block/entity/MobRagdollPartBlockEntity")
                                && call.desc.equals("()Lnet/minecraft/resources/ResourceLocation;")) count++;
                if (count != 1) throw new AssertionError("Texture hook count for " + className + ": " + count);
            }
        }
        System.out.println("PASS: both model hooks, both texture hooks, EMF callbacks and variant API.");
    }
}
