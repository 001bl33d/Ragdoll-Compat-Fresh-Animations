# Building the source

Windows PowerShell and a JDK 21 are required. Run build.ps1 with:

- JavaHome: path to the JDK (containing bin/javac.exe).
- MinecraftDevJar: a NeoForge 1.21.1 development jar containing Mojang-named Minecraft classes.
- DependencyDirectories: directories recursively containing compilation dependency jars.

Example (replace these example paths with your own):

```powershell
./build.ps1 -JavaHome 'D:/tools/jdk-21' -MinecraftDevJar 'D:/dev/neoforge-1.21.1-merged.jar' -DependencyDirectories @('D:/dev/maven-cache', 'D:/minecraft/mods')
```

Dependencies: NeoForge 21.1.x/FML, Minecraft 1.21.1 development classes, Mixin,
MixinExtras 0.5.x, EMF 3.3.12, Sable Player Ragdoll 0.7.5, and their referenced
libraries. These are not distributed in this source archive. A vanilla obfuscated
client jar cannot replace the development jar. This is an offline compilation
script for an existing development environment, not a self-downloading Gradle setup.

The official package was compiled with Java 21 using NeoForge 21.1.252 development
classes and the installed target jars. The user's runtime test used NeoForge 21.1.264.
Output: dist/ragdoll-compat-fresh-animations-neoforge-1.21.1-1.0.0.jar.

VerifyHooks.java is an optional ASM-based signature check against the installed
Sable Player Ragdoll and EMF jars. It is not an in-game test or part of the shipped mod.
The source uses the original mob_ragdoll_emf_compat mod ID so earlier test jars conflict
rather than silently installing a second copy. Remove test versions before installing.
