package compat;

import java.util.HashMap;
import java.util.Map;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;

/** Loads original game textures directly, without the resource-pack stack. */
public final class VanillaTextures {
    private static final Map<ResourceLocation, ResourceLocation> CACHE = new HashMap<>();
    public static ResourceLocation get(ResourceLocation requested) {
        if (!requested.getNamespace().equals("minecraft")) return requested;
        return CACHE.computeIfAbsent(requested, VanillaTextures::load);
    }
    private static ResourceLocation load(ResourceLocation requested) {
        Minecraft mc = Minecraft.getInstance();
        var supplier = mc.getVanillaPackResources().getResource(PackType.CLIENT_RESOURCES, requested);
        if (supplier == null) return requested;
        try (var input = supplier.get()) {
            NativeImage image = NativeImage.read(input);
            ResourceLocation clean = ResourceLocation.fromNamespaceAndPath(
                "mob_ragdoll_emf_compat", "vanilla/" + requested.getPath());
            mc.getTextureManager().register(clean, new DynamicTexture(image));
            return clean;
        } catch (java.io.IOException e) {
            org.slf4j.LoggerFactory.getLogger("MobRagdollEMFCompat")
                .warn("Unable to load original texture {}: {}", requested, e.toString());
            return requested;
        }
    }
}
