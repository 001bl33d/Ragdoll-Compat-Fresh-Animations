package compat;

import net.neoforged.fml.common.Mod;
import net.neoforged.api.distmarker.Dist;

@Mod(value = "mob_ragdoll_emf_compat", dist = Dist.CLIENT)
public final class MobEmfCompat {
    public MobEmfCompat() {
        org.slf4j.LoggerFactory.getLogger("MobRagdollEMFCompat")
                .info("Ragdoll Compat: Fresh Animations 1.0.0 loaded (Sable 0.7.5 / EMF 3.3.12)");
    }
}


