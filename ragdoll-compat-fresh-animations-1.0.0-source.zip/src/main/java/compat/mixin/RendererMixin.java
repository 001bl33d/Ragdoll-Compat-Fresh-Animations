package compat.mixin;

import compat.MobScope;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.leo.sableplayerragdoll.mob.block.entity.MobRagdollPartBlockEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets = "dev.leo.sableplayerragdoll.mob.client.MobRagdollPartBlockEntityRenderer", remap = false)
public abstract class RendererMixin {
    @WrapOperation(method = "renderReplay",
        at = @At(value = "INVOKE", target = "Ldev/leo/sableplayerragdoll/mob/block/entity/MobRagdollPartBlockEntity;texture()Lnet/minecraft/resources/ResourceLocation;"))
    private net.minecraft.resources.ResourceLocation compat$texture(MobRagdollPartBlockEntity part,
        Operation<net.minecraft.resources.ResourceLocation> original) {
        return compat.VanillaTextures.get(original.call(part));
    }
    @WrapMethod(method = "renderReplay")
    private boolean compat$scope(MobRagdollPartBlockEntity entity, float tick, PoseStack pose,
                                  MultiBufferSource buffers, int light, Operation<Boolean> original) {
        try (MobScope scope = new MobScope()) { return original.call(entity, tick, pose, buffers, light); }
    }
    @WrapOperation(method = "renderReplay",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;getModel()Lnet/minecraft/client/model/EntityModel;"))
    private EntityModel<?> compat$model(LivingEntityRenderer<?, ?> renderer, Operation<EntityModel<?>> original) {
        EntityModel<?> model = original.call(renderer);
        return MobScope.prepare(renderer, model);

    }
}

