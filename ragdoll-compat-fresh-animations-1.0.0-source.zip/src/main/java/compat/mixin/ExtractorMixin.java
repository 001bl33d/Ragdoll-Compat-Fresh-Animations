package compat.mixin;

import compat.MobScope;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets = "dev.leo.sableplayerragdoll.mob.client.MobRagdollClientExtractor", remap = false)
public abstract class ExtractorMixin {
    @WrapMethod(method = "extractAndSend(Lnet/minecraft/world/entity/LivingEntity;)V")
    private static void compat$scope(LivingEntity entity, Operation<Void> original) {
        try (MobScope scope = new MobScope()) { original.call(entity); }
    }
    @WrapOperation(method = "extractAndSend(Lnet/minecraft/world/entity/LivingEntity;)V",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;getModel()Lnet/minecraft/client/model/EntityModel;"))
    private static EntityModel<?> compat$model(LivingEntityRenderer<?, ?> renderer, Operation<EntityModel<?>> original) {
        EntityModel<?> model = original.call(renderer);
        return MobScope.prepare(renderer, model);

    }
}

