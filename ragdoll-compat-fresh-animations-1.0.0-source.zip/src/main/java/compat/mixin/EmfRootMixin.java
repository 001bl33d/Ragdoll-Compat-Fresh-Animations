package compat.mixin;

import compat.MobScope;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "traben.entity_model_features.models.parts.EMFModelPartRoot", remap = false)
public abstract class EmfRootMixin {
    @Inject(method = {"animate", "animateNoPause", "oneTimeRunnable"}, at = @At("HEAD"), cancellable = true)
    private void compat$pause(CallbackInfo ci) { if (MobScope.active()) ci.cancel(); }
}
