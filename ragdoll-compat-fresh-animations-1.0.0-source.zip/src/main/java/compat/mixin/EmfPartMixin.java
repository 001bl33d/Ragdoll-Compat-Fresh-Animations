package compat.mixin;

import compat.MobScope;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "traben.entity_model_features.models.parts.EMFModelPart", remap = false)
public abstract class EmfPartMixin {
    @Shadow abstract void renderLikeVanilla(PoseStack pose, VertexConsumer vertices, int light, int overlay, int color);
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void compat$vanilla(PoseStack pose, VertexConsumer vertices, int light, int overlay, int color, CallbackInfo ci) {
        if (MobScope.active()) {
            renderLikeVanilla(pose, vertices, light, overlay, color);
            ci.cancel();
        }
    }
}
