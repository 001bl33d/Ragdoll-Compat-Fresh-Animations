package compat.mixin;

import compat.VanillaTextures;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.leo.sableplayerragdoll.mob.block.entity.MobRagdollPartBlockEntity;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets = "dev.leo.sableplayerragdoll.mob.client.MobRagdollQuadRenderer", remap = false)
public abstract class QuadTextureMixin {
    @WrapOperation(method = "render",
        at = @At(value = "INVOKE", target = "Ldev/leo/sableplayerragdoll/mob/block/entity/MobRagdollPartBlockEntity;texture()Lnet/minecraft/resources/ResourceLocation;"))
    private static ResourceLocation compat$texture(MobRagdollPartBlockEntity part, Operation<ResourceLocation> original) {
        return VanillaTextures.get(original.call(part));
    }
}
