package compat;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import traben.entity_model_features.EMFManager;
import traben.entity_model_features.models.IEMFModel;
import traben.entity_model_features.models.parts.EMFModelPartRoot;
import traben.entity_model_features.models.parts.EMFModelPartWithState;

/** Uses independent vanilla models while a mob's ragdoll is captured or drawn. */
public final class MobScope implements AutoCloseable {
    private static final ThreadLocal<MobScope> CURRENT = new ThreadLocal<>();
    private static final Map<Class<?>, List<Field>> FIELDS = new ConcurrentHashMap<>();
    private static final Map<EntityModel<?>, EntityModel<?>> CLEAN = new WeakHashMap<>();
    private static final Set<Class<?>> WARNED = new HashSet<>();
    private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger("MobRagdollEMFCompat");
    private final MobScope previous;
    private final List<Swap> swaps = new ArrayList<>();
    private record Swap(Object owner, Field field, Object original) {}

    public MobScope() { previous = CURRENT.get(); CURRENT.set(this); }
    public static boolean active() { return CURRENT.get() != null; }

    public static EntityModel<?> prepare(LivingEntityRenderer<?, ?> renderer, EntityModel<?> model) {
        MobScope scope = CURRENT.get();
        if (scope == null) return model;
        EntityModel<?> clean = clean(model);
        scope.replaceModels(renderer);
        for (Field field : fields(renderer.getClass())) {
            Object value = read(field, renderer);
            if (value instanceof Iterable<?> layers)
                for (Object layer : layers)
                    if (layer instanceof RenderLayer<?, ?>) scope.replaceModels(layer);
        }
        return clean;
    }

    private void replaceModels(Object owner) {
        for (Field field : fields(owner.getClass())) {
            Object value = read(field, owner);
            if (value instanceof EntityModel<?> model) {
                EntityModel<?> clean = clean(model);
                if (clean != model && field.getType().isInstance(clean)) {
                    write(field, owner, clean);
                    swaps.add(new Swap(owner, field, model));
                }
            }
        }
    }

    private static EntityModel<?> clean(EntityModel<?> original) {
        if (!(original instanceof IEMFModel emf) || !emf.emf$isEMFModel()) return original;
        EntityModel<?> cached = CLEAN.get(original);
        if (cached != null) return cached;
        EMFModelPartRoot root = emf.emf$getEMFRootModel();
        if (root == null) return original;
        EMFModelPartRoot pending = EMFManager.lastCreatedRootModelPart;
        try {
            // The constructor must not associate this new model with an EMF root.
            EMFManager.lastCreatedRootModelPart = null;
            ModelPart vanilla = copy(root, new IdentityHashMap<>());
            var constructor = original.getClass().getDeclaredConstructor(ModelPart.class);
            constructor.setAccessible(true);
            EntityModel<?> model = (EntityModel<?>) constructor.newInstance(vanilla);
            if (model instanceof IEMFModel test && test.emf$isEMFModel())
                throw new IllegalStateException("Clean model unexpectedly linked to EMF");
            CLEAN.put(original, model);
            LOG.info("Created independent vanilla ragdoll model: {}", original.getClass().getSimpleName());
            return model;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            if (WARNED.add(original.getClass()))
                LOG.warn("Cannot create clean ragdoll model for {}; keeping original: {}", original.getClass().getName(), ex.toString());
            return original;
        } finally {
            EMFManager.lastCreatedRootModelPart = pending;
        }
    }

    @SuppressWarnings("unchecked")
    private static ModelPart copy(ModelPart original, Map<ModelPart, ModelPart> copies) {
        if (copies.containsKey(original)) return copies.get(original);
        List<ModelPart.Cube> cubes;
        Map<String, ModelPart> children;
        PartPose pose;
        float sx = 1, sy = 1, sz = 1;
        boolean visible = true, hidden = false;
        if (original instanceof EMFModelPartWithState part) {
            var state = part.allKnownStateVariants.get(0);
            if (state == null) throw new IllegalStateException("No preserved vanilla state");
            cubes = state.cuboids(); children = state.variantChildren(); pose = state.defaultTransform();
            sx = state.xScale(); sy = state.yScale(); sz = state.zScale();
            visible = state.visible(); hidden = state.hidden();
        } else {
            cubes = (List<ModelPart.Cube>) read(named(ModelPart.class, "cubes"), original);
            children = (Map<String, ModelPart>) read(named(ModelPart.class, "children"), original);
            pose = original.getInitialPose();
        }
        Map<String, ModelPart> childCopies = new LinkedHashMap<>();
        ModelPart result = new ModelPart(new ArrayList<>(cubes), childCopies);
        copies.put(original, result);
        for (var child : children.entrySet()) childCopies.put(child.getKey(), copy(child.getValue(), copies));
        result.setInitialPose(pose); result.loadPose(pose);
        result.xScale = sx; result.yScale = sy; result.zScale = sz;
        result.visible = visible; result.skipDraw = hidden;
        return result;
    }

    private static Field named(Class<?> type, String name) {
        return fields(type).stream().filter(f -> f.getName().equals(name)).findFirst().orElseThrow();
    }
    private static List<Field> fields(Class<?> type) {
        return FIELDS.computeIfAbsent(type, key -> {
            List<Field> result = new ArrayList<>();
            for (Class<?> c = key; c != null && c != Object.class; c = c.getSuperclass())
                for (Field field : c.getDeclaredFields())
                    if (!Modifier.isStatic(field.getModifiers()) && field.trySetAccessible()) result.add(field);
            return List.copyOf(result);
        });
    }
    private static Object read(Field field, Object owner) {
        try { return field.get(owner); }
        catch (IllegalAccessException e) { throw new IllegalStateException(e); }
    }
    private static void write(Field field, Object owner, Object value) {
        try { field.set(owner, value); }
        catch (IllegalAccessException e) { throw new IllegalStateException(e); }
    }
    @Override public void close() {
        try {
            for (int i = swaps.size() - 1; i >= 0; i--) {
                Swap s = swaps.get(i); write(s.field, s.owner, s.original);
            }
        } finally {
            if (previous == null) CURRENT.remove(); else CURRENT.set(previous);
        }
    }
}
