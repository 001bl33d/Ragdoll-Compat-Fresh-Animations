param(
    [Parameter(Mandatory=$true)][string]$JavaHome,
    [Parameter(Mandatory=$true)][string]$MinecraftDevJar,
    [Parameter(Mandatory=$true)][string[]]$DependencyDirectories
)
$ErrorActionPreference = 'Stop'
# MinecraftDevJar must contain Mojang-named Minecraft 1.21.1 development classes.
# Dependencies must include NeoForge/FML, Mixin, MixinExtras, EMF 3.3.12,
# Sable Player Ragdoll 0.7.5 and their compilation dependencies. Nothing is bundled.
Push-Location $PSScriptRoot
try {
    $classPath = @((Resolve-Path -LiteralPath $MinecraftDevJar).Path)
    foreach ($directory in $DependencyDirectories) {
        $classPath += Get-ChildItem -LiteralPath $directory -Recurse -Filter *.jar |
            Where-Object Name -NotMatch 'sources|javadoc|userdev' | Select-Object -ExpandProperty FullName
    }
    $stamp = [Guid]::NewGuid().ToString('N')
    $classes = "build/classes-$stamp"
    New-Item -ItemType Directory -Force $classes,dist,build/temp | Out-Null
    $compileArgs = @('--release','21','-proc:none','-classpath',
        ('"'+(($classPath -join ';').Replace('\','/'))+'"'),'-d',('"'+$classes+'"'))
    $compileArgs += Get-ChildItem src/main/java -Recurse -Filter *.java |
        ForEach-Object { '"'+$_.FullName.Replace('\','/')+'"' }
    Set-Content build/compile.args $compileArgs
    & (Join-Path $JavaHome 'bin/javac.exe') '@build/compile.args'
    if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
    $tempPath = (Resolve-Path build/temp).Path
    & (Join-Path $JavaHome 'bin/jar.exe') "-J-Djava.io.tmpdir=$tempPath" --create --file dist/ragdoll-compat-fresh-animations-neoforge-1.21.1-1.0.0.jar -C $classes . -C src/main/resources .
    if ($LASTEXITCODE -ne 0) { throw 'Packaging failed' }
    Get-FileHash dist/ragdoll-compat-fresh-animations-neoforge-1.21.1-1.0.0.jar -Algorithm SHA256
} finally { Pop-Location }
